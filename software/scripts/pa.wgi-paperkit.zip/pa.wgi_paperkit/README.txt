==============================================================================
Grundlagen wissenschaftlichen Arbeitens (PA.WGI.WA.PS)
Peter Paul Beran, Michael Derntl

------------------------------------------------------------------------------

In diesem Readme-File wird erklärt, wie Sie mit einer herkömmlichen LaTeX-
Installation eine LaTeX-Quelldatei zu einem PDF kompilieren.
Da es viele verschiedene Entwicklungsumgebungen gibt, die das Setzen von 
LaTeX-Dokumenten vereinfachen, beschränken wir uns hier auf die Variante per Kommandozeile. Benutzen Sie eine TeX-Umgebung wie TeXNicCenter oder Lyx, so trifft diese Anleitung nicht zu.

Falls Sie Fragen haben, stellen Sie diese bitte im Forum.

------------------------------------------------------------------------------

In diesem Ordner finden Sie folgende Dateien:
	baboon.png
	demo.pdf
	literatur.bib
	llncs.cls
	Makefile
	paper.tex
	peppers.png	
	README.txt
	splncs03.bst

1)  Navigieren Sie in der Shell, Eingabeaufforderung oder im Terminal zu dem 
    aktuellen Ordner.

2)  Setzen Sie das Dokument zunächst, z.B. mit dem Kommando pdflatex. Sie
    können die Datei auch vorher umbenennen.
        pdflatex paper

3)  Ignorieren Sie Warnungen (Warnings), Errors sollten jedoch keine auf-
    treten.
    
4)  pdflatex sollte in dem Verzeichnis nun die folgenden Dateien zusätzlich
    erstellt haben:
        paper.pdf
        paper.log
        paper.aux

5)  Sie können die PDF-Datei ansehen, jedoch fehlen hier noch sämtliche Quer-
    verweise und die gesamte Bibliographie.

6)  Rufen Sie nun BibTex auf, welches die Verweise aus 'paper.aux' auflöst:
        bibtex paper

7)  Nun sollten folgende Dateien erstellt worden sein:
        paper.blg
        paper.bbl

8)  Rufen Sie zweimal hintereinander pdflatex auf:
        pdflatex paper
        pdflatex paper
    Nach dem ersten Aufruf sollten immer noch Warnings ausgegeben werden - das
    ist normal. Nach dem zweiten Aufruf sollten keine Warnings mehr auftreten.
	Das fertige 'paper.pdf' sollte nun so aussehen wie die Datei 'demo.pdf'.

9)  Sie können nun an der Source-Datei 'paper.tex' Änderungen vornehmen. Wenn
    Sie neue Labels und Referenzen erstellen, muss latex zum Übernehmen der
    Änderungen zweimal aufgerufen werden. 
    
10) Die Datei 'literatur.bib' können Sie bearbeiten. Wenn Sie neue Literatur-
    verweise einfügen, dann müssen Sie latex aufrufen, dann bibtex, und dann 
    noch zwei Mal latex.