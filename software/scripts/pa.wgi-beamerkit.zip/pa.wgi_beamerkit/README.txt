==============================================================================
Grundlagen wissenschaftlichen Arbeitens (PA.WGI.WA.PS)
Peter Paul Beran, Michael Derntl

------------------------------------------------------------------------------

Bitte halten Sie sich an das README.txt zu dem Paper-Kit. Der Ablauf zum
Erstellen einer Beamer-Präsentation erfolgt analog dazu.